package com.julianotorquato07.cloudlab01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudLab01Application {

	public static void main(String[] args) {
		SpringApplication.run(CloudLab01Application.class, args);
	}
}
